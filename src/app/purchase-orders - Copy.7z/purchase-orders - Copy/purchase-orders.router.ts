import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FixedTableComponent } from './fixed-table/fixed-table.component';
import { FeatureTableComponent } from './feature-table/feature-table.component';
import { PurchaseOrdersComponent } from './purchase-orders/purchase-orders.component';
import { PurchaseOrderLinesComponent } from './purchase-order-lines/purchase-order-lines.component';

const materialWidgetRoutes: Routes = [
  { path: 'fixed', component: FixedTableComponent , data: { animation: 'fixed' }},
  { path: 'featured', component: FeatureTableComponent , data: { animation: 'featured' }},
  { path: '', component: PurchaseOrdersComponent},
  { path: 'lines', component: PurchaseOrderLinesComponent}
];

@NgModule({
  imports: [
    RouterModule.forChild(materialWidgetRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class PurchaseOrdersRouterModule {}
